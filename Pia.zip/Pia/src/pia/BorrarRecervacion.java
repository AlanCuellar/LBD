package piaamauri;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class BorrarRecervacion extends javax.swing.JFrame {

    public BorrarRecervacion() {
        initComponents();
        setLocationRelativeTo(null);     
        MostrarDatos(""); 
        Botones();          
    }
  
    void Botones(){
        BtnBuscar.setOpaque(false);
        BtnBuscar.setContentAreaFilled(false);
        BtnBuscar.setBorderPainted(false);
        BtnBuscar1.setOpaque(false);
        BtnBuscar1.setContentAreaFilled(false);
        BtnBuscar1.setBorderPainted(false);
        BtnModificar.setOpaque(false);
        BtnModificar.setContentAreaFilled(false);
        BtnModificar.setBorderPainted(false);
        Txtid.setBackground(new Color(0,0,0,2));
        TxtNumEmpleado.setBackground(new Color(0,0,0,2));
        TxtHotel.setBackground(new Color(0,0,0,2));
        TxtHabitacion.setBackground(new Color(0,0,0,2));
    }
    
    void MostrarDatos(String valor){
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("numero de reservacion");
        modelo.addColumn("id del cliente");
        modelo.addColumn("Hotel");
        modelo.addColumn("Numero del Cuarto");
        modelo.addColumn("Tipo de Habitacion");
        modelo.addColumn("Fecha de Entrada");
        modelo.addColumn("Fecha de salida");
        TEmpleados.setModel(modelo);
        String []datos = new String [7];
        String sql= "";
        if(valor.equals("")){
            sql = "SELECT * FROM reservacion";
        }else{
            sql = "SELECT * FROM reservacion WHERE Usuario_id='"+valor+"'";
        } 
        try {
            Statement st= con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                datos[4] = rs.getString(5);
                datos[5] = rs.getString(6);
                datos[6] = rs.getString(7);
                modelo.addRow(datos);
            }
            TEmpleados.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(Formulario.class.getName()).log(Level.SEVERE, null, ex);
        }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.JPopupMenu Eliminar = new javax.swing.JPopupMenu();
        Escojer = new javax.swing.JMenuItem();
        BtnBuscar1 = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        TxtHotel = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        BtnModificar = new javax.swing.JButton();
        TxtNumEmpleado = new javax.swing.JTextField();
        BtnBuscar = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        TEmpleados = new javax.swing.JTable();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        Txtid = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jSeparator5 = new javax.swing.JSeparator();
        TxtHabitacion = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();

        Eliminar.setToolTipText("Eliminar");
        Eliminar.setName(""); // NOI18N

        Escojer.setText("Escoger");
        Escojer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                EscojerActionPerformed(evt);
            }
        });
        Eliminar.add(Escojer);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(0, 0));
        setMinimumSize(new java.awt.Dimension(1015, 555));
        setUndecorated(true);
        getContentPane().setLayout(null);

        BtnBuscar1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        BtnBuscar1.setForeground(new java.awt.Color(255, 255, 255));
        BtnBuscar1.setText("Buscar");
        BtnBuscar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscar1ActionPerformed(evt);
            }
        });
        getContentPane().add(BtnBuscar1);
        BtnBuscar1.setBounds(510, 390, 120, 27);

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Hotel:");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(230, 210, 90, 30);

        jSeparator4.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator4.setAlignmentX(1.0F);
        getContentPane().add(jSeparator4);
        jSeparator4.setBounds(330, 240, 220, 20);

        TxtHotel.setBackground(new java.awt.Color(0, 51, 51));
        TxtHotel.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtHotel.setForeground(new java.awt.Color(255, 255, 255));
        TxtHotel.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtHotel.setOpaque(false);
        TxtHotel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtHotelActionPerformed(evt);
            }
        });
        getContentPane().add(TxtHotel);
        TxtHotel.setBounds(330, 210, 220, 30);

        jLabel2.setIcon(new javax.swing.ImageIcon("C:\\Users\\abrah\\Pictures\\FlechaB2.png")); // NOI18N
        jLabel2.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel2);
        jLabel2.setBounds(20, 30, 40, 30);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("numero de recervacion:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(10, 160, 310, 30);

        jLabel4.setFont(new java.awt.Font("Showcard Gothic", 0, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("-");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel4);
        jLabel4.setBounds(940, 10, 20, 20);

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Numero de empleado");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(110, 390, 260, 30);

        jLabel6.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("X");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel6);
        jLabel6.setBounds(970, 10, 20, 30);

        jLabel8.setFont(new java.awt.Font("MV Boli", 0, 48)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("              Borrar recervacion");
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 10, 1010, 80);

        BtnModificar.setBackground(new java.awt.Color(255, 255, 255));
        BtnModificar.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        BtnModificar.setForeground(new java.awt.Color(255, 255, 255));
        BtnModificar.setText("Enviar");
        BtnModificar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnModificarMouseClicked(evt);
            }
        });
        BtnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnModificar);
        BtnModificar.setBounds(590, 180, 100, 27);

        TxtNumEmpleado.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtNumEmpleado.setForeground(new java.awt.Color(255, 255, 255));
        TxtNumEmpleado.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtNumEmpleado.setOpaque(false);
        TxtNumEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtNumEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(TxtNumEmpleado);
        TxtNumEmpleado.setBounds(380, 390, 110, 30);

        BtnBuscar.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        BtnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        BtnBuscar.setText("Mostrar Todo");
        BtnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnBuscar);
        BtnBuscar.setBounds(640, 390, 165, 27);

        TEmpleados.setBackground(new java.awt.Color(153, 153, 153));
        TEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TEmpleados.setComponentPopupMenu(Eliminar);
        TEmpleados.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        TEmpleados.setGridColor(new java.awt.Color(0, 0, 0));
        TEmpleados.setOpaque(false);
        jScrollPane1.setViewportView(TEmpleados);
        TEmpleados.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (TEmpleados.getColumnModel().getColumnCount() > 0) {
            TEmpleados.getColumnModel().getColumn(0).setHeaderValue("Title 1");
            TEmpleados.getColumnModel().getColumn(1).setHeaderValue("Title 2");
            TEmpleados.getColumnModel().getColumn(2).setHeaderValue("Title 3");
            TEmpleados.getColumnModel().getColumn(3).setHeaderValue("Title 4");
        }

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(180, 430, 600, 130);

        jSeparator2.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator2.setAlignmentX(1.0F);
        getContentPane().add(jSeparator2);
        jSeparator2.setBounds(380, 410, 110, 30);

        jSeparator3.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator3.setAlignmentX(1.0F);
        getContentPane().add(jSeparator3);
        jSeparator3.setBounds(330, 190, 220, 20);

        Txtid.setBackground(new java.awt.Color(0, 51, 51));
        Txtid.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        Txtid.setForeground(new java.awt.Color(255, 255, 255));
        Txtid.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        Txtid.setOpaque(false);
        Txtid.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtidActionPerformed(evt);
            }
        });
        getContentPane().add(Txtid);
        Txtid.setBounds(330, 160, 220, 30);

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Habitacion:");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(170, 270, 151, 30);

        jSeparator5.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator5.setAlignmentX(1.0F);
        getContentPane().add(jSeparator5);
        jSeparator5.setBounds(330, 300, 220, 20);

        TxtHabitacion.setBackground(new java.awt.Color(0, 51, 51));
        TxtHabitacion.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtHabitacion.setForeground(new java.awt.Color(255, 255, 255));
        TxtHabitacion.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtHabitacion.setOpaque(false);
        TxtHabitacion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtHabitacionActionPerformed(evt);
            }
        });
        getContentPane().add(TxtHabitacion);
        TxtHabitacion.setBounds(330, 270, 220, 30);

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/f2.jpg"))); // NOI18N
        getContentPane().add(jLabel1);
        jLabel1.setBounds(0, 0, 1030, 570);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        this.setState(BorrarRecervacion.ICONIFIED);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void TxtidActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtidActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtidActionPerformed

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
               MostrarDatos("");      
    }//GEN-LAST:event_BtnBuscarActionPerformed

    private void TxtNumEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtNumEmpleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtNumEmpleadoActionPerformed

    private void BtnBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscar1ActionPerformed
        MostrarDatos(TxtNumEmpleado.getText());
    }//GEN-LAST:event_BtnBuscar1ActionPerformed

    private void EscojerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_EscojerActionPerformed
        int Fila = TEmpleados.getSelectedRow();
        if(Fila >=0){
            Txtid.setText(TEmpleados.getValueAt(Fila, 0).toString());
            TxtHotel.setText(TEmpleados.getValueAt(Fila, 2).toString());
            TxtHabitacion.setText(TEmpleados.getValueAt(Fila, 3).toString());
           
        }else{
            JOptionPane.showMessageDialog(null, "Primero Preciona Una Fia");
        }
    }//GEN-LAST:event_EscojerActionPerformed

    private void BtnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnModificarActionPerformed
        try {
            String Habitacion_id="";
            String Hotel="";
            String Tipo_Habitacion="";
            String Num_Habitacion="";
            String Num_Cuartos="";
            String sql = "SELECT * FROM habitaciones_ocupadas WHERE Hotel ='"+TxtHotel.getText()+"' AND Habitacion='"+TxtHabitacion.getText()+"'";
                   Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
             while(rs.next()){
                Habitacion_id = rs.getString("Habitacion_id");
                Hotel = rs.getString("Hotel");
                Tipo_Habitacion = rs.getString("Tipo_Habitacion");
                Num_Habitacion = rs.getString("Habitacion");
                Num_Cuartos = rs.getString("Num_Cuartos");
                
            }
             
             PreparedStatement pst = con.prepareStatement("INSERT INTO habitacion (Habitacion_id,Hotel,Tipo_Habitacion,Num_Habitacion,Num_Cuartos) values(?,?,?,?,?)");
                

                pst.setString(1, Habitacion_id);
                pst.setString(2, Hotel);
                pst.setString(3, Tipo_Habitacion);
                pst.setString(4, Num_Habitacion);
                pst.setString(5, Num_Cuartos);
                 pst.executeUpdate();
             
                PreparedStatement pst2 = con.prepareStatement("DELETE FROM reservacion WHERE Recervacion_id='"+Txtid.getText()+"'");
                pst2.executeUpdate();
                
                PreparedStatement pst3 = con.prepareStatement("DELETE FROM habitaciones_ocupadas WHERE Habitacion_id='"+Habitacion_id+"'");
                pst3.executeUpdate();
                JOptionPane.showMessageDialog(null, "Ya quedo, se elimino "+Txtid.getText());
                
            MostrarDatos("");
        }catch (SQLException ex) {
            Logger.getLogger(BorrarRecervacion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_BtnModificarActionPerformed

    private void BtnModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnModificarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnModificarMouseClicked

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        this.setVisible(false);
        IndexAdmin a = new IndexAdmin();             
        a.setVisible(true);
    }//GEN-LAST:event_jLabel2MouseClicked

    private void TxtHotelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtHotelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtHotelActionPerformed

    private void TxtHabitacionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtHabitacionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtHabitacionActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BorrarRecervacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BorrarRecervacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BorrarRecervacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BorrarRecervacion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BorrarRecervacion().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnBuscar1;
    private javax.swing.JButton BtnModificar;
    private javax.swing.JMenuItem Escojer;
    private javax.swing.JTable TEmpleados;
    private javax.swing.JTextField TxtHabitacion;
    private javax.swing.JTextField TxtHotel;
    private javax.swing.JTextField TxtNumEmpleado;
    private javax.swing.JTextField Txtid;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    // End of variables declaration//GEN-END:variables
    conectar cc = new conectar();
    Connection con = cc.conexion();
}
