package piaamauri;

import java.awt.Color;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class CrearUsuario extends javax.swing.JFrame {

    public CrearUsuario() {
        initComponents();
        setLocationRelativeTo(null);
        Txt();
        MostrarDatos(""); 
        Botones();          
    }
    
    void Txt(){
        TxtUsuario.setBackground(new Color(0,0,0,2));
        TxtContraseña1.setBackground(new Color(0,0,0,2));
        TxtNumEmpleado.setBackground(new Color(0,0,0,2));
        TxtNombre.setBackground(new Color(0,0,0,2));
        TxtTelefono.setBackground(new Color(0,0,0,2));
        TxtDireccion.setBackground(new Color(0,0,0,2));
    }
    
    void Botones(){
        BtnBuscar.setOpaque(false);
        BtnBuscar.setContentAreaFilled(false);
        BtnBuscar.setBorderPainted(false);
        BtnBuscar1.setOpaque(false);
        BtnBuscar1.setContentAreaFilled(false);
        BtnBuscar1.setBorderPainted(false);
        BtnModificar.setOpaque(false);
        BtnModificar.setContentAreaFilled(false);
        BtnModificar.setBorderPainted(false);
    }
    
    void MostrarDatos(String valor){
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Numero de Usuario");
        modelo.addColumn("Usuario");
        modelo.addColumn("Password");
        modelo.addColumn("Tipo de Usuario");
        TEmpleados.setModel(modelo);
        String []datos = new String [4];
        String sql= "";
        if(valor.equals("")){
            sql = "SELECT * FROM usuarios";
        }else{
            sql = "SELECT * FROM usuarios WHERE Usuario_id='"+valor+"'";
        } 
        try {
            Statement st= con.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while(rs.next()){
                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(4);
                modelo.addRow(datos);
            }
            TEmpleados.setModel(modelo);
        } catch (SQLException ex) {
            Logger.getLogger(Formulario.class.getName()).log(Level.SEVERE, null, ex);
        }
}

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPopupMenu2 = new javax.swing.JPopupMenu();
        jMenuItem1 = new javax.swing.JMenuItem();
        TxtContraseña = new javax.swing.JTextField();
        TxtNombre = new javax.swing.JTextField();
        BtnBuscar1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        BtnModificar = new javax.swing.JButton();
        TxtNumEmpleado = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        BtnBuscar = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jScrollPane1 = new javax.swing.JScrollPane();
        TEmpleados = new javax.swing.JTable();
        jSeparator2 = new javax.swing.JSeparator();
        TxtUsuario = new javax.swing.JTextField();
        TxtContraseña1 = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        TxtDireccion = new javax.swing.JTextField();
        TxtTelefono = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();

        jMenuItem1.setText("Escoger");
        jMenuItem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jMenuItem1ActionPerformed(evt);
            }
        });
        jPopupMenu2.add(jMenuItem1);

        TxtContraseña.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtContraseña.setForeground(new java.awt.Color(255, 255, 255));
        TxtContraseña.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtContraseña.setOpaque(false);
        TxtContraseña.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtContraseñaActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(51, 0, 0));
        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        setLocation(new java.awt.Point(0, 0));
        setMinimumSize(new java.awt.Dimension(1015, 555));
        setUndecorated(true);
        getContentPane().setLayout(null);

        TxtNombre.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtNombre.setForeground(new java.awt.Color(255, 255, 255));
        TxtNombre.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtNombre.setOpaque(false);
        TxtNombre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtNombreActionPerformed(evt);
            }
        });
        getContentPane().add(TxtNombre);
        TxtNombre.setBounds(720, 120, 220, 40);

        BtnBuscar1.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        BtnBuscar1.setForeground(new java.awt.Color(255, 255, 255));
        BtnBuscar1.setText("Buscar");
        BtnBuscar1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnBuscar1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscar1ActionPerformed(evt);
            }
        });
        getContentPane().add(BtnBuscar1);
        BtnBuscar1.setBounds(510, 390, 120, 27);

        jLabel1.setIcon(new javax.swing.ImageIcon("C:\\Users\\abrah\\Pictures\\FlechaB2.png")); // NOI18N
        jLabel1.setText("jLabel1");
        jLabel1.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel1);
        jLabel1.setBounds(20, 20, 30, 30);

        jLabel3.setBackground(new java.awt.Color(255, 255, 255));
        jLabel3.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Usuario:");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(110, 110, 110, 40);

        jLabel4.setFont(new java.awt.Font("Showcard Gothic", 0, 48)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("-");
        jLabel4.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel4.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel4MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel4);
        jLabel4.setBounds(940, 10, 20, 20);

        jLabel5.setBackground(new java.awt.Color(255, 255, 255));
        jLabel5.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Numero de empleado");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(110, 390, 260, 30);

        jLabel6.setFont(new java.awt.Font("Showcard Gothic", 0, 24)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("X");
        jLabel6.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        jLabel6.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel6MouseClicked(evt);
            }
        });
        getContentPane().add(jLabel6);
        jLabel6.setBounds(970, 10, 20, 30);

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Contraseña:");
        getContentPane().add(jLabel7);
        jLabel7.setBounds(60, 160, 160, 30);

        jLabel8.setFont(new java.awt.Font("MV Boli", 0, 48)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("              Ingresar Cliente");
        jLabel8.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        getContentPane().add(jLabel8);
        jLabel8.setBounds(0, 10, 1010, 80);

        BtnModificar.setBackground(new java.awt.Color(255, 255, 255));
        BtnModificar.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        BtnModificar.setForeground(new java.awt.Color(255, 255, 255));
        BtnModificar.setText("Enviar");
        BtnModificar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnModificar.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                BtnModificarMouseClicked(evt);
            }
        });
        BtnModificar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnModificarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnModificar);
        BtnModificar.setBounds(350, 220, 100, 27);

        TxtNumEmpleado.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtNumEmpleado.setForeground(new java.awt.Color(255, 255, 255));
        TxtNumEmpleado.setText("           ");
        TxtNumEmpleado.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtNumEmpleado.setOpaque(false);
        TxtNumEmpleado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtNumEmpleadoActionPerformed(evt);
            }
        });
        getContentPane().add(TxtNumEmpleado);
        TxtNumEmpleado.setBounds(380, 390, 110, 30);

        jSeparator3.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator3.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator3.setAlignmentX(1.0F);
        getContentPane().add(jSeparator3);
        jSeparator3.setBounds(720, 230, 220, 20);

        BtnBuscar.setFont(new java.awt.Font("Stencil", 0, 18)); // NOI18N
        BtnBuscar.setForeground(new java.awt.Color(255, 255, 255));
        BtnBuscar.setText("Mostrar Todo");
        BtnBuscar.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        BtnBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnBuscarActionPerformed(evt);
            }
        });
        getContentPane().add(BtnBuscar);
        BtnBuscar.setBounds(640, 390, 165, 27);

        jSeparator1.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator1.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator1.setAlignmentX(1.0F);
        getContentPane().add(jSeparator1);
        jSeparator1.setBounds(380, 410, 110, 30);

        TEmpleados.setBackground(new java.awt.Color(153, 153, 153));
        TEmpleados.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        TEmpleados.setComponentPopupMenu(jPopupMenu2);
        TEmpleados.setGridColor(new java.awt.Color(0, 0, 0));
        TEmpleados.setOpaque(false);
        jScrollPane1.setViewportView(TEmpleados);
        TEmpleados.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (TEmpleados.getColumnModel().getColumnCount() > 0) {
            TEmpleados.getColumnModel().getColumn(0).setHeaderValue("Title 1");
            TEmpleados.getColumnModel().getColumn(1).setHeaderValue("Title 2");
            TEmpleados.getColumnModel().getColumn(2).setHeaderValue("Title 3");
            TEmpleados.getColumnModel().getColumn(3).setHeaderValue("Title 4");
        }

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(180, 420, 600, 130);

        jSeparator2.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator2.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator2.setAlignmentX(1.0F);
        getContentPane().add(jSeparator2);
        jSeparator2.setBounds(230, 140, 220, 20);

        TxtUsuario.setBackground(new java.awt.Color(0, 51, 51));
        TxtUsuario.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtUsuario.setForeground(new java.awt.Color(255, 255, 255));
        TxtUsuario.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtUsuario.setOpaque(false);
        TxtUsuario.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtUsuarioActionPerformed(evt);
            }
        });
        getContentPane().add(TxtUsuario);
        TxtUsuario.setBounds(230, 110, 220, 40);

        TxtContraseña1.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtContraseña1.setForeground(new java.awt.Color(255, 255, 255));
        TxtContraseña1.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtContraseña1.setOpaque(false);
        TxtContraseña1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtContraseña1ActionPerformed(evt);
            }
        });
        getContentPane().add(TxtContraseña1);
        TxtContraseña1.setBounds(220, 160, 220, 40);

        jLabel9.setBackground(new java.awt.Color(255, 255, 255));
        jLabel9.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("Telefono:");
        getContentPane().add(jLabel9);
        jLabel9.setBounds(590, 200, 123, 40);

        jLabel10.setBackground(new java.awt.Color(255, 255, 255));
        jLabel10.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Nombre Completo:");
        getContentPane().add(jLabel10);
        jLabel10.setBounds(490, 120, 230, 40);

        jLabel11.setBackground(new java.awt.Color(255, 255, 255));
        jLabel11.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Direccion:");
        getContentPane().add(jLabel11);
        jLabel11.setBounds(580, 160, 140, 40);

        jSeparator4.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator4.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator4.setAlignmentX(1.0F);
        getContentPane().add(jSeparator4);
        jSeparator4.setBounds(220, 190, 220, 30);

        jSeparator5.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator5.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator5.setAlignmentX(1.0F);
        getContentPane().add(jSeparator5);
        jSeparator5.setBounds(720, 150, 220, 20);

        jSeparator6.setBackground(new java.awt.Color(0, 0, 0));
        jSeparator6.setForeground(new java.awt.Color(0, 0, 0));
        jSeparator6.setAlignmentX(1.0F);
        getContentPane().add(jSeparator6);
        jSeparator6.setBounds(720, 190, 220, 20);

        TxtDireccion.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtDireccion.setForeground(new java.awt.Color(255, 255, 255));
        TxtDireccion.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtDireccion.setOpaque(false);
        TxtDireccion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtDireccionActionPerformed(evt);
            }
        });
        getContentPane().add(TxtDireccion);
        TxtDireccion.setBounds(720, 160, 220, 40);

        TxtTelefono.setFont(new java.awt.Font("Stencil", 0, 24)); // NOI18N
        TxtTelefono.setForeground(new java.awt.Color(255, 255, 255));
        TxtTelefono.setBorder(javax.swing.BorderFactory.createEmptyBorder(1, 1, 1, 1));
        TxtTelefono.setOpaque(false);
        TxtTelefono.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TxtTelefonoActionPerformed(evt);
            }
        });
        getContentPane().add(TxtTelefono);
        TxtTelefono.setBounds(720, 200, 220, 40);

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/f2.jpg"))); // NOI18N
        getContentPane().add(jLabel2);
        jLabel2.setBounds(0, 0, 1060, 570);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel4MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel4MouseClicked
        this.setState(this.ICONIFIED);
    }//GEN-LAST:event_jLabel4MouseClicked

    private void TxtUsuarioActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtUsuarioActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtUsuarioActionPerformed

    private void jLabel6MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel6MouseClicked
        System.exit(0);
    }//GEN-LAST:event_jLabel6MouseClicked

    private void BtnBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscarActionPerformed
        MostrarDatos("");       
    }//GEN-LAST:event_BtnBuscarActionPerformed

    private void TxtNumEmpleadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtNumEmpleadoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtNumEmpleadoActionPerformed

    private void BtnBuscar1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnBuscar1ActionPerformed
        MostrarDatos(TxtNumEmpleado.getText());
    }//GEN-LAST:event_BtnBuscar1ActionPerformed

    private void jMenuItem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jMenuItem1ActionPerformed
        int Fila = TEmpleados.getSelectedRow();
        if(Fila >=0){

            TxtUsuario.setText(TEmpleados.getValueAt(Fila, 1).toString());
            TxtContraseña.setText(TEmpleados.getValueAt(Fila, 2).toString());     
        }else{
            JOptionPane.showMessageDialog(null, "Primero Preciona Una Fia");
        }
        
    }//GEN-LAST:event_jMenuItem1ActionPerformed
    private void BtnModificarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnModificarActionPerformed
        String Usuario = TxtUsuario.getText();
        String Password = TxtContraseña1.getText();
        String Direccion = TxtDireccion.getText();
        String Telefono = TxtTelefono.getText();
        String Rango= "Usuario";
        String NombreCompleto = TxtNombre.getText();
 

        if(!(Usuario.equals("") || Password.equals("") || NombreCompleto.equals("") || Telefono.equals("") || Direccion.equals(""))){
            try {
                       String[] RecortarNombre = NombreCompleto.split(" ");
            String Nombre = RecortarNombre[0];
            String ApellidoPaterno = RecortarNombre[1];
            String ApellidoMaterno = RecortarNombre[2];
                
                 String cap="";
        String sql = "SELECT * FROM usuarios WHERE Nombre ='"+Usuario+"' AND Password='"+u.MD5(Password)+"' AND Tipo_Usuario='"+Rango+"'";
                   Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);
             while(rs.next()){
                cap = rs.getString("Nombre");
                
            }
             if(!(cap.equalsIgnoreCase(Usuario))){
                
                 
                 sql = "SELECT * FROM cliente WHERE Nombre ='"+Nombre+"' AND Apellido_P='"+Telefono+"' AND Apellido_M='"+Direccion+"'";
            rs = st.executeQuery(sql);
             while(rs.next()){
                cap = rs.getString("Nombre");
                
            }
             if(!(cap.equalsIgnoreCase(Nombre))){
                PreparedStatement pst = con.prepareStatement("INSERT INTO cliente (Nombre,Apellido_P,Apellido_M,Diereccion,Telefono) values(?,?,?,?,?)");
                

                pst.setString(1, Nombre);
                pst.setString(2, ApellidoPaterno);
                pst.setString(3, ApellidoMaterno);
                pst.setString(4, Direccion);
                pst.setString(5, Telefono);
                 pst.executeUpdate();
                 JOptionPane.showMessageDialog(null, "ya quedo en cliente");
                 
                 pst = con.prepareStatement("INSERT INTO usuarios (Nombre,Password,Tipo_Usuario) values(?,?,?)");         

                pst.setString(1, Usuario);
                pst.setString(2, u.MD5(Password));
                pst.setString(3, Rango); 
                JOptionPane.showMessageDialog(null, "ya quedo en Usuario");
                pst.executeUpdate();
             }else{
                 JOptionPane.showMessageDialog(null, "Ya existe este cliente");
             }
                 
                 
                 JOptionPane.showMessageDialog(null, "Listo Calisto");
             }else{
                 JOptionPane.showMessageDialog(null, "Ya existe este Usuario");
             }

            } catch (SQLException ex) {
                Logger.getLogger(CrearUsuario.class.getName()).log(Level.SEVERE, null, ex);
            }
             
        }else{
            JOptionPane.showMessageDialog(null, "Faltaron Datos");
        } 
            MostrarDatos("");     
   
            
            
    }//GEN-LAST:event_BtnModificarActionPerformed
    private void BtnModificarMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_BtnModificarMouseClicked
        // TODO add your handling code here:
    }//GEN-LAST:event_BtnModificarMouseClicked

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked
        this.setVisible(false);
        IndexAdmin a = new IndexAdmin();             
        a.setVisible(true);
    }//GEN-LAST:event_jLabel1MouseClicked

    private void TxtContraseña1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtContraseña1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtContraseña1ActionPerformed

    private void TxtContraseñaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtContraseñaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtContraseñaActionPerformed

    private void TxtNombreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtNombreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtNombreActionPerformed

    private void TxtDireccionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtDireccionActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtDireccionActionPerformed

    private void TxtTelefonoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TxtTelefonoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TxtTelefonoActionPerformed

    public static void main(String args[]) {

        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CrearUsuario.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CrearUsuario().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnBuscar;
    private javax.swing.JButton BtnBuscar1;
    private javax.swing.JButton BtnModificar;
    private javax.swing.JTable TEmpleados;
    private javax.swing.JTextField TxtContraseña;
    private javax.swing.JTextField TxtContraseña1;
    private javax.swing.JTextField TxtDireccion;
    private javax.swing.JTextField TxtNombre;
    private javax.swing.JTextField TxtNumEmpleado;
    private javax.swing.JTextField TxtTelefono;
    private javax.swing.JTextField TxtUsuario;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JMenuItem jMenuItem1;
    private javax.swing.JPopupMenu jPopupMenu2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    // End of variables declaration//GEN-END:variables
    conectar cc = new conectar();
    Connection con = cc.conexion();
    MD5 u = new MD5();
}
